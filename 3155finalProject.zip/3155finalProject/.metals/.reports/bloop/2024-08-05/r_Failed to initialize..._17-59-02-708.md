error id: CCd0eKhe3aocnaZ7qZZD2Q==
### Bloop error:

Failed to initialize communication: Socket closed
#### Short summary: 

Failed to initialize communication: Socket closed